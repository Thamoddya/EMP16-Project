<!-- Header navigation -->
<div class="nav-wrapper fixed-top">
    <div class="container">
        <nav class="navbar navbar-toggleable-sm navbar-expand-md">
            <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target=".navbar-collapse">
                ☰
            </button>
            <a class="navbar-brand mx-auto" href="<?php echo e(route('Home')); ?>"><img alt="vertexcooperation" class="image-logo" src="<?php echo e(asset('images/icons/logo.png')); ?>"></a>

            <div class="navbar-collapse collapse">
                <ul class="navbar-nav nav-justified w-100 nav-fill">
                    <li class="nav-item">
                        <a class="nav-link js-scroll-trigger <?php echo e(Route::currentRouteName() == 'Home' ? 'active' : ''); ?>" href="<?php echo e(route('Home')); ?>">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link js-scroll-trigger <?php echo e(Route::currentRouteName() == 'About' ? 'active' : ''); ?>" href="<?php echo e(route('About')); ?>">About</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link js-scroll-trigger <?php echo e(Route::currentRouteName() == 'Partner' ? 'active' : ''); ?>" href="<?php echo e(route('Partner')); ?>">Partners</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link js-scroll-trigger <?php echo e(Route::currentRouteName() == 'Support' ? 'active' : ''); ?>" href="#">Support</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link js-scroll-trigger <?php echo e(Route::currentRouteName() == 'Blog' ? 'active' : ''); ?>" href="#">Blog</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link js-scroll-trigger <?php echo e(Route::currentRouteName() == 'Contact' ? 'active' : ''); ?>" href="#">Contact</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link js-scroll-trigger <?php echo e(Route::currentRouteName() == 'Team' ? 'active' : ''); ?>" href="<?php echo e(route('Team')); ?>">Team</a>
                    </li>

                </ul>
            </div>
        </nav>
    </div>
</div>
<?php /**PATH C:\Users\thamo\OneDrive\Desktop\Laravel-Projects\vertex_co\resources\views/components/header.blade.php ENDPATH**/ ?>